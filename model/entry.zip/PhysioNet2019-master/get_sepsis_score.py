#!/usr/bin/env python3

import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import model_from_json


def get_sepsis_score(data, model):

    
    col = ['HR', 'O2Sat', 'Temp', 'SBP', 'MAP', 'DBP', 'Resp', 'EtCO2',
       'BaseExcess', 'HCO3', 'FiO2', 'pH', 'PaCO2', 'SaO2', 'AST', 'BUN',
       'Alkalinephos', 'Calcium', 'Chloride', 'Creatinine', 'Bilirubin_direct',
       'Glucose', 'Lactate', 'Magnesium', 'Phosphate', 'Potassium',
       'Bilirubin_total', 'TroponinI', 'Hct', 'Hgb', 'PTT', 'WBC',
       'Fibrinogen', 'Platelets', 'Age', 'Gender', 'Unit1', 'Unit2',
       'HospAdmTime', 'ICULOS']
    
    data = pd.DataFrame(data, columns = col)

    data.drop(['EtCO2', 'BaseExcess','HCO3', 'FiO2', 'pH', 'PaCO2', 'SaO2', 'AST', 'BUN', 'Alkalinephos','Calcium', 'Chloride', 'Creatinine', 'Bilirubin_direct' , 'Resp','Lactate','Magnesium','Phosphate','Potassium', 'Bilirubin_total', 'TroponinI','Hct', 'Hgb','PTT',  'WBC', 'Fibrinogen', 'Platelets',"Unit1", 'Unit2', "Glucose",'DBP','SBP'], axis = 1, inplace = True)
    data.fillna(method='bfill',inplace=True)
    data.fillna(method='ffill',inplace=True)
    

    
    if sum(pd.isna(data['MAP'])) !=0 : 
        data['MAP'] =  [87] * len(data['MAP'] )
    if sum(pd.isna(data['Temp'])) !=0 : 
        data['Temp'] =  [36.7] * len(data['Temp'] )
    if sum(pd.isna(data['HR'])) !=0 : 
        data['HR'] =  [83.9] * len(data['HR'] )
    if sum(pd.isna(data['O2Sat'])) !=0 : 
        data['O2Sat'] =  [95] * len(data['O2Sat'] )

    scaler = MinMaxScaler()

    data = scaler.fit_transform(data)



    probabilities = model.predict(data)
    
    mse = np.mean(np.power(data - probabilities , 2), axis=1)
    df_error = pd.DataFrame({'reconstruction_error': mse})
    outliers = df_error.index[df_error.reconstruction_error > 0.18].tolist()


    for i in range(0, len(df_error) ):
        if df_error.reconstruction_error[i] > 0.23 :
            predictions = True
        else :
            predictions = False

    score = 0

    return score, predictions



def load_sepsis_model():
    json_file = open('model2.json', 'r')
    loaded_model_json = json_file.read()
    json_file.close()
    loaded_model = model_from_json(loaded_model_json)
    loaded_model.load_weights("model2.h5")
    return(loaded_model)







